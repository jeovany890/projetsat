<?php

namespace App\Entity;

use App\Repository\EntrepriseRepository;
use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;

#[ORM\Entity(repositoryClass: EntrepriseRepository::class)]
#[ORM\Table(name: "entreprise")]
class Entreprise
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\Column(type: 'string', length: 255)]
    private ?string $nom = null;

    #[ORM\Column(type: 'string', length: 13, unique: true)]
    private ?string $ifu = null;

    #[ORM\Column(type: 'boolean', options: ['default' => false])]
    private bool $charteAcceptee = false;

    #[ORM\Column(type: 'datetime', nullable: true)]
    private ?\DateTimeInterface $dateAcceptationCharte = null;

    #[ORM\Column(type: 'string', length: 50)]
    private ?string $rccm = null;

    #[ORM\Column(type: 'string', length: 100)]
    private ?string $secteur = null;

    // nombreEmployes : plus de colonne BD — calculé depuis les départements

    #[ORM\Column(type: 'string', length: 20)]
    private ?string $telephone = null;

    #[ORM\Column(type: 'string', length: 180)]
    private ?string $email = null;

    #[ORM\Column(type: 'text', nullable: true)]
    private ?string $adresse = null;

    #[ORM\Column(type: 'string', length: 20, options: ['default' => 'EN_ATTENTE'])]
    private string $statut = 'EN_ATTENTE';

    #[ORM\Column(type: 'datetime')]
    private ?\DateTimeInterface $dateCreation = null;

    #[ORM\Column(type: 'datetime', nullable: true)]
    private ?\DateTimeInterface $dateValidation = null;

    /**
     * Traçabilité audit : quel admin a validé cette entreprise.
     * Nullable car les entreprises EN_ATTENTE n'ont pas encore de validateur.
     */
    #[ORM\ManyToOne(targetEntity: Administrateur::class)]
    #[ORM\JoinColumn(name: 'valide_by', nullable: true, onDelete: 'SET NULL')]
    private ?Administrateur $validateurAdmin = null;

    // ── Relations ──

    #[ORM\OneToMany(targetEntity: Departement::class, mappedBy: 'entreprise', cascade: ['persist', 'remove'])]
    private Collection $departements;

    /**
     * Relation inverse vers les RSSI de cette entreprise.
     * Permet $entreprise->getRssis() et la suppression CASCADE automatique
     * quand l'entreprise est supprimée (onDelete: CASCADE est sur RSSI.entreprise_id).
     */
    #[ORM\OneToMany(targetEntity: RSSI::class, mappedBy: 'entreprise')]
    private Collection $rssis;

    public function __construct()
    {
        $this->dateCreation = new \DateTime();
        $this->departements = new ArrayCollection();
        $this->rssis        = new ArrayCollection();
    }

    public function getId(): ?int { return $this->id; }

    public function getNom(): ?string { return $this->nom; }
    public function setNom(string $nom): static { $this->nom = $nom; return $this; }

    public function getIfu(): ?string { return $this->ifu; }
    public function setIfu(string $ifu): static { $this->ifu = $ifu; return $this; }

    public function getRccm(): ?string { return $this->rccm; }
    public function setRccm(string $rccm): static { $this->rccm = $rccm; return $this; }

    public function isCharteAcceptee(): bool { return $this->charteAcceptee; }
    public function setCharteAcceptee(bool $v): static { $this->charteAcceptee = $v; return $this; }
    public function getDateAcceptationCharte(): ?\DateTimeInterface { return $this->dateAcceptationCharte; }
    public function setDateAcceptationCharte(?\DateTimeInterface $d): static { $this->dateAcceptationCharte = $d; return $this; }
    public function accepterCharte(): static
    {
        $this->charteAcceptee          = true;
        $this->dateAcceptationCharte   = new \DateTime();
        return $this;
    }

    public function getSecteur(): ?string { return $this->secteur; }
    public function setSecteur(string $secteur): static { $this->secteur = $secteur; return $this; }

    /**
     * Calculé dynamiquement en parcourant les départements.
     * L'ancienne colonne nombre_employes n'était jamais mise à jour → supprimée.
     */
    public function getNombreEmployes(): int
    {
        $total = 0;
        foreach ($this->departements as $dept) {
            $total += $dept->getEmployes()->count();
        }
        return $total;
    }

    public function getTelephone(): ?string { return $this->telephone; }
    public function setTelephone(string $t): static { $this->telephone = $t; return $this; }

    public function getEmail(): ?string { return $this->email; }
    public function setEmail(string $email): static { $this->email = $email; return $this; }

    public function getAdresse(): ?string { return $this->adresse; }
    public function setAdresse(?string $adresse): static { $this->adresse = $adresse; return $this; }

    public function getStatut(): string { return $this->statut; }
    public function setStatut(string $statut): static { $this->statut = $statut; return $this; }

    public function getDateCreation(): ?\DateTimeInterface { return $this->dateCreation; }
    public function setDateCreation(\DateTimeInterface $d): static { $this->dateCreation = $d; return $this; }

    public function getDateValidation(): ?\DateTimeInterface { return $this->dateValidation; }
    public function setDateValidation(?\DateTimeInterface $d): static { $this->dateValidation = $d; return $this; }

    // ── Traçabilité audit ──
    public function getValidateurAdmin(): ?Administrateur { return $this->validateurAdmin; }
    public function setValidateurAdmin(?Administrateur $admin): static { $this->validateurAdmin = $admin; return $this; }

    // ── Relations ──
    public function getDepartements(): Collection { return $this->departements; }
    public function addDepartement(Departement $departement): static
    {
        if (!$this->departements->contains($departement)) {
            $this->departements->add($departement);
            $departement->setEntreprise($this);
        }
        return $this;
    }
    public function removeDepartement(Departement $departement): static
    {
        if ($this->departements->removeElement($departement)) {
            if ($departement->getEntreprise() === $this) {
                $departement->setEntreprise(null);
            }
        }
        return $this;
    }

    public function getRssis(): Collection { return $this->rssis; }

    // ── Méthodes utilitaires ──
    public function isValidee(): bool { return $this->statut === 'ACTIF'; }
    public function isEnAttente(): bool { return $this->statut === 'EN_ATTENTE'; }
    public function isSuspendue(): bool { return $this->statut === 'SUSPENDU'; }
    public function isRejetee(): bool { return $this->statut === 'REJETE'; }

    public function valider(?Administrateur $admin = null): static
    {
        $this->statut         = 'ACTIF';
        $this->dateValidation = new \DateTime();
        if ($admin) {
            $this->validateurAdmin = $admin;
        }
        return $this;
    }

    public function suspendre(): static { $this->statut = 'SUSPENDU'; return $this; }
    public function rejeter(): static { $this->statut = 'REJETE'; return $this; }
    public function reactiver(): static { $this->statut = 'ACTIF'; return $this; }

    public function __toString(): string { return $this->nom ?? ''; }
}