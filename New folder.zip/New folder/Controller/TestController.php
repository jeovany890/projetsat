<?php
namespace App\Controller;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class TestController
{
    #[Route('/test-brut', name: 'app_test_brut')]
    public function index(): Response
    {
        return new Response('Ça marche !');
    }
}